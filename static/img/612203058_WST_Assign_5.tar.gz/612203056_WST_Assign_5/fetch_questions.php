<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "127.0.0.1"; // Use 127.0.0.1 instead of localhost
$username = "root";
$password = "";
$dbname = "quiz_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Fetch questions
$sql = "SELECT id, question, option1, option2, option3, option4 FROM questions ORDER BY RAND() LIMIT 5";
$result = $conn->query($sql);

if (!$result) {
    die("Query Failed: " . $conn->error);
}

$questions = [];
while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}

// Send JSON response
header("Content-Type: application/json");
echo json_encode($questions);
?>
