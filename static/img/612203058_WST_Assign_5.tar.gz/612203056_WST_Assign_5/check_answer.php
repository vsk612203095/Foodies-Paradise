<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quiz_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);
$score = 0;

foreach ($data as $answer) {
    $id = $answer['id'];
    $selected_option = $answer['answer'];

    $sql = "SELECT correct_option FROM questions WHERE id = $id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    if ($row['correct_option'] == $selected_option) {
        $score++;
    }
}

echo json_encode(["score" => $score]);

$conn->close();
?>
